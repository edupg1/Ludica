﻿using UnityEngine;
using System.Collections;

public class disparo : MonoBehaviour {

    // Daño inflingido
    public int danho = 1;

    // El disparo es del jugador o del enemigo?
    public bool esDisparoEnemigo = false;

    void Start()
    {
        // Que desaparezca el objeto disparo despues de un tiempo definido
        Destroy(gameObject, 20); // 20 segundos
    }
}
