﻿using UnityEngine;
using System.Collections;

public class seguirPersonaje : MonoBehaviour {

	public Transform principal;
	public float separacion = 30f;


	// Update is called once per frame
	void Update () {
		transform.position = new Vector3(principal.position.x+separacion,principal.position.y+60,transform.position.z);
	}
}
