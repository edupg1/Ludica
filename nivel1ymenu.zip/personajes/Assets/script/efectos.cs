﻿using UnityEngine;
using System.Collections;

public class efectos : MonoBehaviour {

    /// <summary>
    /// Singleton
    /// </summary>
    public static efectos Instancia;

    public ParticleSystem efectoDesintegrar;

    void Awake()
    {
        // Registramos el singleton
        if (Instancia != null)
        {
            Debug.LogError("Muchas instancias de EfectosEspecialesScript!");
        }

        Instancia = this;
    }

    /// <summary>
    /// Se crea una explosion en un lugar en particular
    /// </summary>
    public void Explosion(Vector3 posicion)
    {
        
        // Explosión
        instanciar(efectoDesintegrar, posicion);
    }

    /// <summary>
    /// Instanciamos el sistema de particulas desde los reutilizados
    /// </summary>
    private ParticleSystem instanciar(ParticleSystem reutilizado, Vector3 posicion)
    {
        ParticleSystem nuevoSistemaParticulas = Instantiate(
        reutilizado,
        posicion,
        Quaternion.identity
        ) as ParticleSystem;

        // Nos aseguramos que sea destruido
        Destroy(
        nuevoSistemaParticulas.gameObject,
        nuevoSistemaParticulas.startLifetime
        );

        return nuevoSistemaParticulas;
    }
}
