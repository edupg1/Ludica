﻿using System;

public interface Ben
{
    void execute();
}
