﻿using UnityEngine;

public interface IEyes {
    void see(Collider2D col);
}
