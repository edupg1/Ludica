﻿using UnityEngine;
using System.Collections;

public class ControladorPersonaje : MonoBehaviour {

	public float fuerzaSalto = 200f;

	static public bool enSuelo = true;
	public Transform comprobadorSuelo;
	private float comprobadorRadio =0.7f;
	public LayerMask mascaraSuelo;

	static bool dobleSalto = false;

	private Animator animator;

	private bool corriendo = false;
    public float velocidad = 0.5f;

	void Awake(){
		animator = GetComponent<Animator>();
	}

	// Use this for initialization
	void Start () {
	
	}
    
    void FixedUpdate(){
		if(corriendo){
			GetComponent<Rigidbody2D>().velocity = new Vector2(velocidad, GetComponent<Rigidbody2D>().velocity.y);
		}
		animator.SetFloat("VelX", GetComponent<Rigidbody2D>().velocity.x);
		//enSuelo = Physics2D.OverlapCircle(comprobadorSuelo.position, comprobadorRadio+1, mascaraSuelo);
		//animator.SetBool("isGrounded", enSuelo);
        if (enSuelo)
        {
            dobleSalto = false;
        }  
        
    }
    void OnCollisionEnter2D(Collision2D col)
    {
        enSuelo = true;

    }
	
	// Update is called once per frame
	void Update () {
        
        
        if (Input.GetKeyUp(KeyCode.W)){
			
			// Hacemos que salte si puede saltar
			if(enSuelo || dobleSalto){
				GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.y, fuerzaSalto);
                //rigidbody2D.AddForce(new Vector2(0, fuerzaSalto));
                
                enSuelo = false;
                
                if (!dobleSalto){
						dobleSalto = true;
                }
                else { dobleSalto = false;
                    //enSuelo = true;
                }
                    
			}
			
		}
        animator.SetBool("isGrounded", enSuelo);
        if (Input.GetKeyDown(KeyCode.D))
        {
            corriendo = true;
        }
        if (Input.GetKeyUp(KeyCode.D))
        {
            corriendo = false;
        }

        // diparando
        bool disparo1 = Input.GetKey(KeyCode.Space);
      

        if (disparo1)
        {
            arma arma1 = GetComponent<arma>();
            if (arma1 != null)
            {
                // Falso porque el jugador no es el enemigo
                arma1.Ataque(false);
            }
        }

    }
}
