﻿using UnityEngine;
using System.Collections;

public class Puntuacion : MonoBehaviour {

	private int puntuacion = 0;
    public TextMesh marcador;
    public TextMesh textValor;

	// Use this for initialization
	void Start () {
		NotificationCenter.DefaultCenter().AddObserver(this, "IncrementarPuntos");
        actualizarMarcador();
	}

	void IncrementarPuntos(Notification notificacion){
		int puntosAIncrementar = (int)notificacion.data;
		puntuacion+=puntosAIncrementar;
		//Debug.Log("Incrementado "+puntosAIncrementar+" puntos. Total ganados: "+puntuacion);
        actualizarMarcador();
	}
	
    void actualizarMarcador()
    {
        marcador.text = puntuacion.ToString();
        textValor.text= puntuacion.ToString();
    }
	// Update is called once per frame
	void Update () {
	
	}
}
