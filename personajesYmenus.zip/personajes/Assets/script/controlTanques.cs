﻿using UnityEngine;
using System.Collections;

public class controlTanques : MonoBehaviour {


    public Vector2 velocidad = new Vector2(50, 50);
    public Vector2 movimiento;
    public Vector2 direccion = new Vector2(-1, 0);
    private arma[] armas;

    void Awake()
    {
        // Instanciamos el objeto arma
        armas = GetComponentsInChildren<arma>();
    }

    // Update is called once per frame
    void Update()
    {
        movimiento = new Vector2(
        velocidad.x * direccion.x,
        velocidad.y * direccion.y);

        foreach (arma arma1 in armas)
        {
            // Auto disparamos
            if (arma1 != null && arma1.PuedeAtacar)
            {
                arma1.Ataque(true);
            }
        }
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movimiento;
    }
}
