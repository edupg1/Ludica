﻿using UnityEngine;
using System.Collections;

public class movDisparo : MonoBehaviour {

    public Vector2 velocidad = new Vector2(50, 50);
    public Vector2 movimiento;
    public Vector2 direccion = new Vector2(-1, 0);

    // Update is called once per frame
    void Update()
    {
        movimiento = new Vector2(
        velocidad.x * direccion.x,
        velocidad.y * direccion.y);
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movimiento;
    }
}
