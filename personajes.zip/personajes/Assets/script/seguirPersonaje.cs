﻿using UnityEngine;
using System.Collections;

public class seguirPersonaje : MonoBehaviour {

	public Transform principal;
	public float separacion = 3f;


	// Update is called once per frame
	void Update () {
		transform.position = new Vector3(principal.position.x+separacion,transform.position.y,transform.position.z);
	}
}
