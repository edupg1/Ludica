﻿//using System;

public interface IBen
{
    void execute();
}
