﻿using UnityEngine;

interface ISight {
   void OnPlayerSpotted(Transform player);
}
