﻿using UnityEngine;
using System.Collections;

public class ShootEnemy : MonoBehaviour
{
    
    public int damage = 1;

    
    void Start()
    {
        // Que desaparezca el objeto disparo despues de un tiempo definido
        Destroy(gameObject, 6); // 20 segundos
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Player") {
            
            Destroy(gameObject);
        }else if(col.tag == "obstacle")
        {
            
            Destroy(gameObject);
        }
    }
    void OnCollisionEnter2D(Collider2D col)
    {
        if (col.tag == "Player")
        {
            Destroy(gameObject);
        }
        else if (col.tag == "obstacle")
        {
            Destroy(gameObject);
        }
    }
}
