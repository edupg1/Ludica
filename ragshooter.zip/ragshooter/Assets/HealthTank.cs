﻿using UnityEngine;
using System.Collections;

public class HealthTanque : MonoBehaviour {

    /// <summary>
    /// Numero de puntos de salud
    /// </summary>
    public int ps = 2;
    public int pointWon = 100;

    /// <summary>
    /// Es jugador o enemigo?
    /// </summary>
    public bool isEnemy = true;

    void OnTriggerEnter2D(Collider2D collider)
    {
        //Es un disparo?
        shoot shoot = collider.gameObject.GetComponent<shoot>();
        if (shoot != null)
        {
            // Revisamos si es enemigo o compañero
            if (shoot.isEnemyShoot != isEnemy)
            {
                ps -= shoot.damage;

                // Destruimos el disparo
                // No coloquen solo Destroy()
                //sino eliminaran el Script
                Destroy(shoot.gameObject);

                if (ps <= 0)
                {
                    // Muerto!
                    //efectos.Instancia.Explosion(transform.position);
                    Destroy(gameObject);
                    NotificationCenter.DefaultCenter().PostNotification(this, "IncrementarPuntos", pointWon);
                }
            }
        }
    }
}
