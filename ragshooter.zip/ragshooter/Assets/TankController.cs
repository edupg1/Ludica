﻿using UnityEngine;
using System.Collections;

public class TankController : MonoBehaviour {

    public Vector2 velocity1 = new Vector2(50, 50);
    public Vector2 movement;
    public Vector2 direction = new Vector2(-1, 0);
    private weapon[] weapons;

    void Awake()
    {
        // Instanciamos el objeto arma
        weapons = GetComponentsInChildren<weapon>();
    }

    // Update is called once per frame
    void Update()
    {
        movement = new Vector2(
        velocity1.x * direction.x,
        velocity1.y * direction.y);

        foreach (weapon weapon1 in weapons)
        {
            // Auto disparamos
            if (weapon1 != null && weapon1.PuedeAtacar)
            {
                weapon1.Ataque(true);
            }
        }
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
    }
}
