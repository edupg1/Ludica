﻿using UnityEngine;
using System.Collections;

public class TankController : MonoBehaviour
{
    public Animator animator;
    public int number_bullets = 20;
    public int live = 1000;
    public Transform main_character;
    private bool isShoot = false;
    public float speed = 0.3f;
    private int direction = -1;
    private double time_gun;
    public Transform buller;
    public Transform positionGun;
    public double timeByShoot = 10;

    void Awake()
    {
        animator = GetComponent<Animator>();
    }

    // Use this for initialization
    void Start()
    {

    }

    void FixedUpdate()
    {
        if (direction==1)
        {

            GetComponent<Rigidbody2D>().velocity = new Vector2(speed, GetComponent<Rigidbody2D>().velocity.y);
        }
        else if (direction==-1)
        {

            GetComponent<Rigidbody2D>().velocity = new Vector2(-speed, GetComponent<Rigidbody2D>().velocity.y);
        }

    }
    void OnCollisionEnter2D(Collider2D col)
    {
        if (col.tag == "buller")
        {
            live -= 7;
        }
        else if (col.tag == "grenade")
        {
            live -= 42;
        }
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "buller")
        {
            live -= 7;
        }
        else if (col.tag == "grenade")
        {
            live -= 42;
        }
    }

    public void Shoot()
    {
        // Traemos el componente Transform del buller
        var bullerTransform = Instantiate(buller) as Transform;

        // Asignamos una posicion
        bullerTransform.position = positionGun.position;

        ShootEnemy bullerEnemy = bullerTransform.gameObject.GetComponent<ShootEnemy>();

        moveMisil move = bullerTransform.gameObject.GetComponent<moveMisil>();
        if (move != null)
        {
            print("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
            Vector2 direc = new Vector2(-1, 1);
            move.direction = direc;
        }

    }

    // Update is called once per frame
    void Update()
    {
        float distance = -main_character.position.x + this.transform.position.x;
        if (distance > 5)
        {
            animator.SetBool("walk", false);
            direction = 0;

        }
        else if (distance > 4)
        {
            animator.SetBool("walk", true);
            direction = 1;


        }
        else if (distance < 4 && distance > 2)
        {

            animator.SetBool("walk", false);
            direction = 0;
            if (!isShoot)
            {
                animator.SetTrigger("shoot");
                Shoot();
                isShoot = true;
                time_gun = System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute;

            }
        }
        else if (distance <2)
        {
            if (!isShoot)
            {
                animator.SetTrigger("shoot");
                Shoot();
                isShoot = true;
                time_gun = System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute;

            }
            animator.SetBool("walk", true);
            direction = -1;

        }
        if ((System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute) - time_gun > timeByShoot)
        {
            isShoot = false;
        }
        if (live <= 0)
        {
            Destroy(gameObject);
        }

    }

}