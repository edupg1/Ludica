﻿using UnityEngine;
using System.Collections;

public class weapon : MonoBehaviour
{

    /// <summary>
    /// Componente transform del disparo
    /// </summary>
    public Transform shootreused;

    /// <summary>
    /// Esperaremos un tiempo entre un disparo y otro para generarse
    /// </summary>
    public float standbytimeshoot = 0.25f;

    //--------------------------------
    // Tiempo de espera
    //--------------------------------

    private float timeBetweenShooting;

    void Start()
    {
        timeBetweenShooting = 0f;
    }

    void Update()
    {
        if (timeBetweenShooting > 0)
        {
            timeBetweenShooting -= Time.deltaTime;
        }
    }

    //--------------------------------
    // Disparando desde otro Script
    //--------------------------------

    /// <summary>
    /// Crear un nuevo disparo de ser posible
    /// </summary>
    public void Ataque(bool esEnemigo)
    {
        if (PuedeAtacar)
        {
            timeBetweenShooting = standbytimeshoot;

            // Traemos el componente Transform del DisparoReutilizado
            var disparoTransform = Instantiate(shootreused) as Transform;

            // Asignamos una posicion
            disparoTransform.position = transform.position;

            // Vemos si es fuego enemigo
            shoot disparo = disparoTransform.gameObject.GetComponent<shoot>();
            if (disparo != null)
            {
                disparo.isEnemyShoot = esEnemigo;
            }

            // Hacemos que se mueva siempre a la derecha
            movShoot movimiento = disparoTransform.gameObject.GetComponent<movShoot>();
            if (movimiento != null)
            {
                movimiento.direction = this.transform.right;
            }
        }
    }

    /// <summary>
    /// </summary>
    public bool PuedeAtacar
    {
        get
        {
            return timeBetweenShooting <= 0f;
        }
    }
}
