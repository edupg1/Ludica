﻿using UnityEngine;
using System.Collections;

public class HealhPlayer : MonoBehaviour {

    public int healh = 500;
    public Animator animator;
    public TextMesh HPScore;
    private int cero = 0;
    public GameObject CameraGameOver;
    // Use this for initialization
    void Start () {
        HPScore.text = healh.ToString();
    }
	void OnTriggerEnter2D(Collider2D col)
    {
        if(col.tag == "buller_enemy")
        {
          
            healh -= col.GetComponent<ShootEnemy>().damage;
            if (healh > 0)
            {
                HPScore.text = healh.ToString();
            }
            else { HPScore.text = cero.ToString() ; }
        }
        if (healh <= 0)
        {
            if(animator!= null)
            {
                animator.SetTrigger("dies_knife");
            }
            CameraGameOver.SetActive(true);
            Destroy(gameObject, 3);
        }
    }
    // Update is called once per frame
    void Update () {
	    
	}
}
