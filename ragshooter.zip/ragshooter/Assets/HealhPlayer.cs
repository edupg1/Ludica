﻿using UnityEngine;
using System.Collections;

public class HealhPlayer : MonoBehaviour {

    public int healh = 500;
    public Animator animator;
	// Use this for initialization
	void Start () {
	
	}
	void OnTriggerEnter2D(Collider2D col)
    {
        if(col.tag == "buller_enemy")
        {
            healh -= col.GetComponent<ShootEnemy>().damage;
        }
        if (healh <= 0)
        {
            if(animator!= null)
            {
                animator.SetTrigger("dies_knife");
            }
            Destroy(gameObject, 3);
        }
    }
    // Update is called once per frame
    void Update () {
	    
	}
}
