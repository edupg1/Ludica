﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class SemaphoreManager {
    public static bool level1 = true;
    public static bool level2 = true;
}
