﻿using UnityEngine;

public class AttackGrenadeEnemy : MonoBehaviour, IObserver
{

    public ObjectPoolScript grenadePool;
    public Animator animator;
    public Transform initialPosition;

    public void Observe(SlugEvents ev)
    {
        if (ev == SlugEvents.Grenade)
        {
            GrenadeAttack();
        }
    }

    private void GrenadeAttack()
    {
        //animator.SetTrigger("grenade");
        GameObject grenadeGameObject = grenadePool.GetPooledObject();
        GrenadeControllerEnemy grenadeSpecific = grenadeGameObject.GetComponent<GrenadeControllerEnemy>();
        grenadeSpecific.transform.position = initialPosition.position;
        grenadeSpecific.Init();
        grenadeSpecific.Throw(transform.right);
    }

}
