﻿using UnityEngine;
using System.Collections;

public class Scoring : MonoBehaviour {

    private int scoring = 0;
    public TextMesh score;
    public TextMesh textValor;

    // Use this for initialization
    void Start()
    {
        NotificationCenter.DefaultCenter().AddObserver(this, "IncrementarPuntos");
        actualizarMarcador();
    }

    void IncrementarPuntos(Notification notificacion)
    {
        int puntosAIncrementar = (int)notificacion.data;
        scoring += puntosAIncrementar;
        //Debug.Log("Incrementado "+puntosAIncrementar+" puntos. Total ganados: "+puntuacion);
        actualizarMarcador();
    }

    void actualizarMarcador()
    {
        score.text = scoring.ToString();
        textValor.text = scoring.ToString();
    }
    // Update is called once per frame
    void Update()
    {

    }
}
