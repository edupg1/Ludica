﻿using UnityEngine;
using System.Collections;

public class ManagerPoint : MonoBehaviour
{

    private int point = 0;
    public TextMesh score;
    public TextMesh finalScore;

    public TextMesh finalScoreWin;

    // Use this for initialization
    void Start()
    {
        NotificationCenter.DefaultCenter().AddObserver(this, "IncrementarPuntos");
        actScore();
    }

    void IncrementarPuntos(Notification notification)
    {
        int pointUp = (int)notification.data;
        point += pointUp;
        //Debug.Log("Incrementado "+puntosAIncrementar+" puntos. Total ganados: "+puntuacion);
        actScore();
    }

    void actScore()
    {
        score.text = point.ToString();
        finalScore.text = point.ToString();
        finalScoreWin.text = point.ToString();

    }
    // Update is called once per frame
    void Update()
    {

    }
}
