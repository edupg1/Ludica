﻿using UnityEngine;
using System.Collections;

public class shoot : MonoBehaviour
{

    public int damage = 1;

    public bool isEnemyShoot = false;

    void Start()
    {
        
        Destroy(gameObject, 20);
    }
}
