﻿using UnityEngine;
using System.Collections;

public class HealthObject : MonoBehaviour
{

    public int healh = 60;
    // Use this for initialization
    
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "buller")
        {
            healh -= 10;
        }
        if (healh <= 0)
        {
            
            Destroy(gameObject, 3);
        }
    }
    
}
