﻿using UnityEngine;
using System.Collections;

public class GameWin : MonoBehaviour {
    public GameObject cameraWin;
    public TextMesh finalScoreWin;
    
    // Use this for initialization
    void Start () {
	
	}
	void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "Player" && cameraWin!= null) {
            if (finalScoreWin != null) {
                int pointAct = System.Int32.Parse(finalScoreWin.text);
                finalScoreWin.text = (pointAct + 500).ToString() ;
            }
            cameraWin.SetActive(true);
        }
    }
	// Update is called once per frame
	void Update () {
	
	}
}
