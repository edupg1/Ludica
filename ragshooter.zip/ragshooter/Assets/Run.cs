﻿using UnityEngine;
using EnemyUtils;

public class Run : MonoBehaviour, IEnemyBehavior {

    private Transform player;
    public bool inProgress;
    public int priority = 1;
    public bool interruptible = true;
    private float distanceFromPlayer = 10000;
    public Animator animator;
    public PhysicsSlugEngine physicsController;
    private double timeGrenade= (System.DateTime.Now.Minute * 60 + System.DateTime.Now.Second);
    public ObjectPoolScript grenadeEne;
    public Transform initialPosition;

    void Start() {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update() {
        if (player != null) {
            distanceFromPlayer = transform.position.x - player.position.x;
        }
    }

    public bool CanBeInterrupted() {
        return interruptible;
    }

    public int GetPriority() {
        return priority;
    }

    public bool InProgress() {
        return inProgress;
    }

    public void StartBehavior() {
        inProgress = true;
         animator.SetBool("walking", true);
    }

    public bool UpdateBehavior()
    {
        if (player == null) {
            return false;
        }
        if ((System.DateTime.Now.Minute * 60 + System.DateTime.Now.Second) - timeGrenade > 6)
        {
            timeGrenade = System.DateTime.Now.Minute * 60 + System.DateTime.Now.Second;
        }
        if (distanceFromPlayer < 0.5f && distanceFromPlayer > -0.5f) {
            animator.SetBool("walking", false);
            inProgress = false;
            animator.SetTrigger("knife");
        } else if (distanceFromPlayer < 2f && distanceFromPlayer > -2f) {
            if ((System.DateTime.Now.Minute * 60 + System.DateTime.Now.Second)-timeGrenade > 5) {
                GrenadeAttack();
                timeGrenade = 0;
            }
        } else if (distanceFromPlayer > 0) {
            //physicsController.changeDirection()
        }
        physicsController.MoveForward();
        return true;
    }

    public bool WantToStart() {
        return player != null;
    }

    private void GrenadeAttack()
    {
        animator.SetTrigger("grenade_standing");
        GameObject grenadeGameObject = grenadeEne.GetPooledObject();
        GrenadeControllerEnemy grenadeSpecific = grenadeGameObject.GetComponent<GrenadeControllerEnemy>();
        grenadeSpecific.transform.position = initialPosition.position;
        grenadeSpecific.Init();
        grenadeSpecific.Throw(transform.right);
    }
}
