﻿using UnityEngine;
using System.Collections;

public class Soldier2Controller : MonoBehaviour
{
    public Animator animator;
    public int number_bullets=50;
    public int live=100;
    public Transform main_character;
    private bool isShoot=false;
    public float speed = 0.5f;
    private int direction=-1;
    private double time_gun;
    public Transform buller;
    public Transform positionGun;

    void Awake()
    {
        animator = GetComponent<Animator>();
    }

    // Use this for initialization
    void Start()
    {

    }

    void FixedUpdate()
    {
        if (animator.GetBool("walk_back"))
        {
            
            GetComponent<Rigidbody2D>().velocity = new Vector2(speed, GetComponent<Rigidbody2D>().velocity.y);
        }
        else if (animator.GetBool("walk") )
        {
            
            GetComponent<Rigidbody2D>().velocity = new Vector2(-speed, GetComponent<Rigidbody2D>().velocity.y);
        }

    }
    void Turn()
    {
        if (direction==-1)
        {
            animator.SetBool("walk", false);
            animator.SetTrigger("turn_around");
        }
        else if (direction==1)
        {
            animator.SetBool("walk_back", false);
            animator.SetTrigger("turn_rect");
        }
    }
    void OnCollisionEnter2D(Collision2D col)
    {
        

    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "buller")
        {
            live-=7;
        }else if(col.tag == "grenade")
        {
            live-= 42;
        }
    }

    public void Shoot()
    {
        // Traemos el componente Transform del buller
        var bullerTransform = Instantiate(buller) as Transform;

        // Asignamos una posicion
        bullerTransform.position = positionGun.position;

        ShootEnemy bullerEnemy = bullerTransform.gameObject.GetComponent<ShootEnemy>();
            
        moveShoot move = bullerTransform.gameObject.GetComponent<moveShoot>();
        if (move != null)
        {
            Vector2 direc = new Vector2(direction, 0);
            move.direction = direc;
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        float distance = -main_character.position.x + this.transform.position.x;
        if (distance >5)
        {
            animator.SetBool("walk", false);
            animator.SetBool("walk_back", false);
            
        } else if (distance < 5 && distance > 3 )
        {
            
            if (direction==-1)
                animator.SetBool("walk", true);
            else
            {
                Turn();
                direction = -1;
            }
        } else if (distance < 2 && distance > 0){
            
            if (direction == -1)
            {
                Turn();
                direction = 1;
            }else
            {
                animator.SetBool("walk_back", true);
            }
        }else if( distance <-3 )
        {
            
            if (direction == 1)
                animator.SetBool("walk_back", true);
            else
            {
                Turn();
                direction = 1;
            }
        }else if(distance > -2 && distance < 0) {
            
            if (direction == 1)
            {
                Turn();
                direction = -1;
            }
            else
            {
                animator.SetBool("walk", true);
            }
        }else if(distance < -2 && distance > -3)
        {
            if (direction == 1)
            {
                animator.SetBool("walk", false);
                animator.SetBool("walk_back", false);
                if (!isShoot)
                {
                    animator.SetTrigger("gun");
                    Shoot();
                    isShoot = true;
                    time_gun = System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute;
                    
                }
            }
            else
            {
                Turn();
                direction = 1;
            }
        }
        else if (distance > 2 && distance < 3)
        {
            if (direction == -1) { 
                animator.SetBool("walk", false);
                animator.SetBool("walk_back", false);
                if (!isShoot)
                {
                    animator.SetTrigger("gun");
                    Shoot();
                    
                    isShoot = true;
                    time_gun = System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute;
                    
                }
            }else
            {
                Turn();
                direction = -1;
            }
        }
        if((System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute) - time_gun > 2)
        {
            isShoot = false;
        }
        if (live <= 0)
        {
            Destroy(gameObject);
        }
        
    }
}