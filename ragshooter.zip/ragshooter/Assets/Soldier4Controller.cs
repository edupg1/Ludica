﻿using UnityEngine;
using System.Collections;

public class Soldier4Controller : MonoBehaviour
{
    public Animator animator;
    public int number_bullets = 1200;
    public int live = 400;
    public Transform main_character;
    private bool isShoot = false;
    public float speed = 0.3f;
    private int direction = -1;
    private double time_gun;
    public Transform buller;
    public Transform positionGun;
    private bool firstShoot = true;
    public double timeByShoot = 6;
    public int number_shoots = 0;
    public int max_shoots = 60;
    private System.Random rand = new System.Random();
    float[]  dir_y=new float[60];
    public int WinPoint = 160;
    public TextMesh scoreLive;

    void Awake()
    {
        animator = GetComponent<Animator>();
    }

    // Use this for initialization
    void Start()
    {
        for (int i = 0; i < 60; i++){
            dir_y[i] = (float)((i % 10)-5) * 0.1f;
        }
        scoreLive.text = live.ToString();
    }

    void FixedUpdate()
    {
        if (animator.GetBool("walk_back"))
        {

            GetComponent<Rigidbody2D>().velocity = new Vector2(speed, GetComponent<Rigidbody2D>().velocity.y);
        }
        else if (animator.GetBool("walk"))
        {

            GetComponent<Rigidbody2D>().velocity = new Vector2(-speed, GetComponent<Rigidbody2D>().velocity.y);
        }

    }
    void Turn()
    {
        if (direction == -1)
        {
            animator.SetBool("walk", false);
            animator.SetTrigger("turn_around");
        }
        else if (direction == 1)
        {
            animator.SetBool("walk_back", false);
            animator.SetTrigger("turn_rect");
        }
    }
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.tag == "buller")
        {
            live -= 5;
        }
        else if (col.tag == "grenade")
        {
            live -= 70;
        }
        scoreLive.text = live.ToString();
    }
    void OnCollisionEnter2D(Collider2D col)
    {
        if (col.tag == "buller")
        {
            live -= 5;
        }
        else if (col.tag == "grenade")
        {
            live -= 70;
        }
        scoreLive.text = live.ToString();
    }

    public void Shoot()
    {
        // Traemos el componente Transform del buller
        var bullerTransform = Instantiate(buller) as Transform;

        // Asignamos una posicion
        bullerTransform.position = positionGun.position;

        ShootEnemy bullerEnemy = bullerTransform.gameObject.GetComponent<ShootEnemy>();
       
        
        moveShoot move = bullerTransform.gameObject.GetComponent<moveShoot>();
        if (move != null)
        {
            Vector2 direc = new Vector2(direction, dir_y[number_shoots]);
            move.direction = direc;
        }
        number_bullets--;

    }

    // Update is called once per frame
    void Update()
    {
        float distance = 0;
        if (main_character != null)
        {
            distance = -main_character.position.x + this.transform.position.x;
        }
        if (distance > 7)
        {
            animator.SetBool("walk", false);
            animator.SetBool("walk_back", false);

        }
        else if (distance < 7 && distance > 3)
        {

            if (direction == -1)
                animator.SetBool("walk", true);
            else
            {
                Turn();
                direction = -1;
            }
        }
        else if (distance < -3)
        {

            if (direction == 1)
                animator.SetBool("walk_back", true);
            else
            {
                Turn();
                direction = 1;
            }
        }

        else if (distance < 0 && distance > -3)
        {
            if (direction == 1 && number_bullets > 0)
            {
                animator.SetBool("walk", false);
                animator.SetBool("walk_back", false);
                if (!isShoot)
                {
                    animator.SetTrigger("shoot_back");
                    Shoot();
                    number_shoots++;
                    if (number_shoots >= max_shoots)
                    {
                        isShoot = true;

                    }
                    if (firstShoot)
                    {
                        time_gun = System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute;
                        firstShoot = false;
                    }

                }
            }
            else if (direction == -1)
            {
                Turn();
                direction = -1;
            }
        }
        else if (distance > 0 && distance < 3)
        {
            if (direction == -1 && number_bullets>0)
            {
                animator.SetBool("walk", false);
                animator.SetBool("walk_back", false);
                if (!isShoot)
                {
                    animator.SetTrigger("shoot");
                    Shoot();
                    number_shoots++;
                    if (number_shoots >= max_shoots)
                    {
                        isShoot = true;
                        
                    }
                    if (firstShoot)
                    {
                        time_gun = System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute;
                        firstShoot = false;
                    }

                }
            }
            else if(direction==1)
            {
                Turn();
                direction = -1;
            }
        }
        if ((System.DateTime.Now.Second + 60 * System.DateTime.Now.Minute) - time_gun > timeByShoot)
        {
            isShoot = false;
            number_shoots = 0;
            firstShoot = true;
        }
        if (live <= 0)
        {
            Destroy(gameObject);
            NotificationCenter.DefaultCenter().PostNotification(this, "IncrementarPuntos", WinPoint);
        }

    }

}